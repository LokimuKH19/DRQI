Fp=Fokker Plank
Lp=Laplace
a=Adam

