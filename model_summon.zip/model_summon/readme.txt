DRQI_FokkerPlank2d.py: The DRQI template for solving problems with periodic boundary condition
DRQI_FokkerPlank2d.py: The DRQI template for solving problems with Dirichlet boundary condition
Anyone who uses the codes is requiredzto cite the article "Deep Rayleigh quotient iteration (DRQI) for high-precision numerical solutions of eigenvalue problems for differential operators" 